#include "Circle.h"

float Circle::calcCircumference()
{
	return 2 * 3.14 * radius;
};