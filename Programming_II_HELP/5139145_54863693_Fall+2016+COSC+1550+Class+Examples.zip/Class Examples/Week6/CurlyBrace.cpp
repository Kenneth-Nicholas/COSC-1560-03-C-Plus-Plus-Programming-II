#include <iostream>
using namespace std;

int main()
{
	int num1 = 3,
		num2 = 4;
	
	if (num1 > num2)
	{
		cout << "Num1 is greater than num2.\n";
		cout << "Yeah!!!\n";
	}


	
	return 0;

}
