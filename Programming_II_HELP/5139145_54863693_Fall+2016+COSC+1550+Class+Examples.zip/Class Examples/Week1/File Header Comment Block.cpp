//**********************************************************
//* Your Name Here							               * 
//* COSC 1550.07 Computer Programming I				   * 
//* Program Name:	xxxxxxxxxx.cpp						   * 
//* Homework Number xx, Assignment yy                      *
//* Problem #: xx.x                                        *
//* Due Date:				   			                   * 
//**********************************************************

// For Example:

//**********************************************************
//* Paul Biolchini							               * 
//* COSC 1550.07 Computer Programming I					   * 
//* Program Name:	PersonalInformation.cpp    			   * 
//* Homework Number 1, Assignment 1                        *
//* Problem #: 2.10                                        *
//* Due Date:	8/27/2012   			                   * 
//**********************************************************
