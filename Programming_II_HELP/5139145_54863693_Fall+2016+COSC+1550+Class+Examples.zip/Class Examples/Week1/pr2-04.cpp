// An unruly printing program
#include <iostream>
using namespace std;

int main()
{
	cout << "The following items were top sellers";
	cout << "during the month of June:";
	cout << "Computer games";
	cout << "Coffee";
	cout << "Aspirin";
	return 0;
}
