// MyFirstProgram.cpp
// This is my first program
// COSC 1550 Fall 2009
// Class Example 1
// Paul Biolchini

#include <iostream>

using namespace std;

int main()
{	
	cout 
		<< "Hello World!" << endl
		<< "My First C++ Program!" << endl
		<< "Programming is great." << endl
		<< endl;	

	cout << "  *  " << endl;
	cout << " *** " << endl;

	return 	0;
}


/*

Hello World!
My First C++ Program!
Programming is great.

  *
 ***
Press any key to continue . . .

*/