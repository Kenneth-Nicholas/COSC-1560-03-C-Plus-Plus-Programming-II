// COSC 1550.G1
// Paul Biolchini
// Example 1
// First Example

#include <iostream>

using namespace std;

int main()
{
	// Method 1
	cout << "\tMy name is Paul\n\tThis is Programming I\n\n";
	// Method 2
	cout << "\tMy name is Paul\n" << "\tThis is Programming I\n\n";
	// Method 3
	cout << "\tMy name is Paul\n"
		 << "\tThis is Programming I\n\n";
	// Method 4
	cout << "\tMy name is Paul\n";
	cout << "\tThis is Programming I\n\n";
	// Method 5
	cout << "\tMy name is Paul" << endl;
	cout << "\tThis is Programming I" << endl << endl;



	return 0;
}

/*
My name is Paul
Press any key to continue . . .
*/

/*

"  *"
" ***"
"*****"
" ***"
"  *"   

  */
