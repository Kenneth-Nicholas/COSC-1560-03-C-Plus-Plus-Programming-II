//**********************************************************
//* Paul Biolchini							               
//* COSC 1550.07 Computer Programming I		              
//* Program Name:	HelloWorld.cpp					        
//* Homework Number xx, Assignment yy                      
//* Problem #: xx.x                                        
//* Due Date:  08/25/2016				   			                    
//**********************************************************

#include <iostream>

using namespace std;

//void main(void)
int main()
{
	//cout
	//	<< "Hello,\n"
	//	<< "World!\n" 
	//	<< "How are you\?"
	//	<< 	endl;

	//cout << " *** " << endl;
	//cout << "*****" << endl;


	cout 
		<< " *** " << endl
	    << "*****" << endl
		<< endl;




	return 0;
}

//Hello,
//World!
//How are you ?
//Press any key to continue . . .