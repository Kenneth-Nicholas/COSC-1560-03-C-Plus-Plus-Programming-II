// fstream Example
// COSC 1550
//
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main()
{
	ofstream oFile;
	ifstream iFile;
	iFile.open("MyName.txt");
	string n1,n2,n3;

	iFile >> n1;
	iFile >> n2;
	iFile >> n3;
	iFile.close();

	cout << "The names you entered were: \n";
	cout << n1 << endl;
	cout << n2 << endl;
	cout << n3 << endl;

	cout << "Enter a name: ";
	cin >> n1;
	cout << "Enter a name: ";
	cin >> n2;
	cout << "Enter a name: ";
	cin >> n3;
	cout << "Writing names to the disk.\n";

	oFile.open("MyName.txt");
	oFile << left;
	//oFile << setw(10) << n1 << endl;
	//oFile << setw(10) << n2 << endl;
	//oFile << setw(10) << n3 << endl;
	cout << setw(10) << n1;
	cout << setw(10) << n2;
	cout << setw(10) << n3 << endl;
	oFile << setw(10) << n1;
	oFile << setw(10) << n2;
	oFile << setw(10) << n3 << endl;

	oFile.close();
	cout << "Done.\n";

	return 0;

}