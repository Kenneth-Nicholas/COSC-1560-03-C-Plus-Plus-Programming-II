//**********************************************************
//* Paul Biolchini							                
//* COSC 1550.07 Computer Programming I				        
//* Program Name:	PersonalInformation.cpp    		        
//* Homework Number 1, Assignment 1                        
//* Problem #: 2.14                                        
//* Due Date:	9/3/2015   			                    
//**********************************************************

	///////////////////////////////////////////////
	///////////////////////////////////////////////
	////                                          
	////  Grade:  2 points out of 2 possible    
	////                                          
	///////////////////////////////////////////////
	///////////////////////////////////////////////


//////////////////////////////////////////////////
////
//// Comments:
//// 
//// 
////
//////////////////////////////////////////////////

#include <iostream>
using namespace std;

int main()
{
	cout << "Paul Biolchini\n" 
		<< "123 Fourth Street, St. Louis, MO. 63133\n"
		<< "636-537-2592\n"
		<< "Computer Science\n\n"; //// 

	return 0;
}
/*
Paul Biolchini
123 Fourth Street, St. Louis, MO. 63133
636-537-2592
Computer Science

Press any key to continue . . .
*/