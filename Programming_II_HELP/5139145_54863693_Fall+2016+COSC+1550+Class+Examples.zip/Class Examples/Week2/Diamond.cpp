//**********************************************************
//* Paul Biolchini							                
//* COSC 1550.07 Computer Programming I				        
//* Program Name:	Diamond.cpp    		        
//* Homework Number 1, Assignment 2                        
//* Problem #: 2.16                                        
//* Due Date:	9/3/2015   			                    
//**********************************************************


#include <iostream>
using namespace std;

int main()
{
	cout << "\t   *   \n";
	cout << "\t  ***  \n";
	cout << "\t ***** \n";
	cout << "\t*******\n";
	cout << "\t ***** \n";
	cout << "\t  ***  \n";
	cout << "\t   *   \n\n";


	return 0;
}
