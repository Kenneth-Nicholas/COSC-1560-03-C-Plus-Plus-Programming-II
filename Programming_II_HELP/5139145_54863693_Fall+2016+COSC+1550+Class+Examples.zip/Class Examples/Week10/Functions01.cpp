// COSC 1550
// Class Example
// Functions - Chapter 6

#include <iostream>

using namespace std;

void Display()
{
	cout << "Hello from function \'Display\'\n";
}

int main()
{
	Display();
	Display();
	Display();
	return 0;
}

