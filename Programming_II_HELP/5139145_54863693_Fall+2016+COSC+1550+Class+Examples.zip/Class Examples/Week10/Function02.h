
// function prototypes
int DataIn();
void Display(int);

int num;  // global
