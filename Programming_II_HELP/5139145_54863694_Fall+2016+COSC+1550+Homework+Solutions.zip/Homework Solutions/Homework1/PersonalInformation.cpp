
//**********************************************************
//* Paul Biolchini							               * 
//* COSC 1550.07 Computer Programming I				       * 
//* Program Name:	PersonalInformation.cpp    		       * 
//* Homework Number 1, Assignment 1                        *
//* Problem #:   2.14                                      *
//* Due Date:	9/1/2016	                               * 
//**********************************************************


//Basic C++ program skeleton

#include <iostream>

using namespace std;

int main()
{
	cout
		<< "Paul Biolchini" << endl
		<< "123 Fourth St St. Louis, MO 63119\n"
		<< "123-456-7890\n"
		<< "Computer Science" << endl;
	return 0;
}

// Results:
//
//Paul Biolchini
//123 Fourth St St.Louis, MO 63119
//123 - 456 - 7890
//Computer Science
//Press any key to continue . . .